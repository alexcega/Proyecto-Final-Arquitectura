#!/usr/bin/env bash
./scripts/docker-compose-dev.sh  exec postgres psql -h localhost -U movies movies

