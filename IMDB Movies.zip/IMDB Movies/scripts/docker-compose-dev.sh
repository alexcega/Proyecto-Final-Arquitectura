#!/usr/bin/env bash
docker-compose --env-file=config/dev.env $@
